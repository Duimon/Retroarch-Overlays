Put all the files in your "Retroarch/config/Gambatte/".

Move the "Duimon" folder to your "Retroarch/overlays" folder.

You can rename the Gambatte.slang and Gambatte.cfg to a diferrent core config...

i.e config/SameBoy/Sameboy.cfg & SameBoy.slang

or a content directory set...

i.e. (If your ROMs are in a "Gameboy" folder.) Gameboy.cfg & Gameboy.slang.

The content dirctory pair will work in any core config folder.

You need all custom color settings in your core turned off for the DMG shader to work correctly.

The Gambatte.opt is already configured.